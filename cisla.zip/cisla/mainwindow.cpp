#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPalette pal;


    pal.setColor(QPalette::WindowText,Qt::cyan);

    ui->label->setText("ПУСТАЯ СТРОКА");
    ui->label->setPalette(pal);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{
    double a;
    bool flag;
     QString name =arg1.trimmed();
    QPalette pal;

    {
        a=ui->lineEdit->text().toDouble(&flag);
        pal=ui->label->palette();
        if(name.isEmpty())
        {
            pal.setColor(QPalette::WindowText,Qt::cyan);           
            ui->label->setText("ПУСТАЯ СТРОКА");
        }
        else  if(flag == false)
        {
            pal.setColor(QPalette::WindowText,Qt::red);
            ui->label->setText("НЕ ЧИСЛО");
        }
        else if(a == int(a))
        {
            pal.setColor(QPalette::WindowText,Qt::green);           
            ui->label->setText("ЦЕЛОЕ ЧИСЛО");
        }
        else if(a != int(a))
        {
            pal.setColor(QPalette::WindowText,Qt::magenta);           
            ui->label->setText("ВЕЩЕСТВЕННОЕ ЧИСЛО");
        }

        ui->label->setPalette(pal);// подкрашивание лейблов
        ui->lineEdit->setAutoFillBackground(true);
    }
}

